//  -----------------------------
//  Prerequisite
//  -----------------------------
//  Please check out this guide to create a Remote Asset and
//  import a Remote Asset Reference into your project:
//  https://docs.snap.com/lens-studio/references/guides/lens-features/lens-cloud/remote_assets/remote-assets-overview
//
//  RemoteAssetInfo.js and RemoteAssetsLoader.js are used together to download 
//  remote assets and set Lens content on awake or on demand.
//
//  -----------------------------
//  Script: RemoteAssetInfo.js 
//  -----------------------------
//  
//  Description:    This script links the reference asset to its associated content in the scene
//                  and sets the action to be performed when the remote asset is downloaded.
//
//  Inputs:         "ID" - A unique string that identifies the remote asset
//                  "Reference Asset" - Asset.RemoteReferenceAsset that represents the remote asset in Lens Cloud
//                  "Fallback Asset" (Optional) - Local asset that is used in place of the remote asset if download fails
//                  "Action" - The action to take when the remote asset is downloaded that sets the content in the Lens
//                      - "None" - Downloads the asset without setting Lens content
//                      - "Instantiate Prefab" - Specify the Prefab Parent or leave field empty to instantiate prefab in the root
//                      - "Set Audio Track" - Specify the Audio Component to set Audio Track to. Note - you will have to trigger playing audio yourself
//                      - "Set Image Texture"- Specify the Image Texture to set the Texture to
//                      - "Set Naterial Texture" - Specify the Material to set the Texture to
//                      - "Set Mesh" - Specify the Render Mesh Visual to set the Mesh on
//                      - "Set ML Model" - Specify the ML Component to set the ML Asset on. Tip: Configure your ML model via a callback function.
//                  "Script Component" (Optional) - Component.ScriptComponent containing a callback function
//                  "Function" (Optional) - The callback function that executes when content it set
//                      - Receives the content as a parameter. If Action is None, receives the downloaded asset as a parameter.
//                  "Load On Awake" - Check off to load the asset on awake.
//
//  -----------------------------
//  Script: RemoteAssetsLoader.js
//  -----------------------------
//
//  Description:    This script handles logic for downloading remote assets based on their RemoteAssetInfo.js 
//                  configuration and setting their associated content in the the scene. It loads asset on awake 
//                  if set, and provides a global API for loading assets on demand from other parts of the project.
//
//  Inputs:         "Root" - The parent scene object of children with RemoteAssetInfo.js attached
//
//  -----------------------------
//  Usage
//  -----------------------------
//
//  1. Add the Remote_Assets_Loader_PLACE_IN_OBJECS_PANEL prefab to the Objects panel.
//  2. For each remote asset in your project, add a child scene object to the Remote Assets Info Root.
//  3. Attach RemoteAssetInfo.js to each child scene object from step 2 and configure its inputs.
//  4. On the Remote Assets Loader, add the Remote Assets Info Root to the Root input.
//
//  -----------------------------
//  Global API 
//  -----------------------------
//  
//  Downloads a remote asset and performs its associated action to set Lens content.
//  Calls the onActionComplete callback if provided, passing the Lens content to it.
//  If Action is None, the downloaded asset is passed to onActionComplete.
//
//  global.RemoteAssetLoader.load(string: id, function: onActionComplete);