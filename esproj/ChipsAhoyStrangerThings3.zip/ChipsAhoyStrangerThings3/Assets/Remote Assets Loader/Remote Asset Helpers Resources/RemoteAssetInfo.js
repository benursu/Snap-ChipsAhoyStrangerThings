// RemoteAssetInfo.js
// Version: 1.1.0
// Event: On Awake
// Description: Data structure for a remote asset that gets 
//              loaded by RemoteAssetLoader.js

//@ui {"widget":"label", "label":"<b>Asset Settings</b>"}
//@input string id {"label":"ID", "hint":"Choose a unique string to identify your asset"}
//@input Asset.RemoteReferenceAsset referenceAsset
//@input Asset fallbackAsset

//@ui {"widget":"separator"}
//@ui {"widget":"label", "label":"<b>Set Content on Downloaded Action</b>"}
//@input int action = -1 {"widget":"combobox", "values":[{"label":"None", "value":-1}, {"label":"Instantiate Prefab", "value":0}, {"label":"Set Audio Track", "value":1}, {"label":"Set Image Texture", "value":2}, {"label":"Set Material Texture", "value":3}, {"label":"Set Mesh", "value":4}, {"label":"Set ML Model", "value":5}]}
//@input SceneObject prefabParent {"showIf":"action", "showIfValue" : "0"}
//@input Component.AudioComponent myAudioComponent  {"label" : "Audio", "showIf":"action", "showIfValue" : "1"}
//@input Component.Image myImage {"label" : "Texture", "showIf":"action", "showIfValue" : "2"}
//@input Asset.Material myMaterial  {"label" : "Material", "showIf":"action", "showIfValue" : "3"}
//@input string texturePropertyName  {"label" : "Property", "showIf":"action", "showIfValue" : "3"}
//@input Component.RenderMeshVisual myRenderMeshVisual {"label" : "Mesh Visual", "showIf":"action", "showIfValue" : "4"}
//@input Component.MLComponent myMLComponent {"label" : "ML Component", "showIf":"action", "showIfValue" : "5"}

//@ui {"widget":"separator"}
//@ui {"widget":"label", "label":"<b>On Action Complete Callback</b>"}
//@input Component.ScriptComponent myScriptComponent {"label" : "Script Component"}
//@input string funcName {"label" : "Function"}

//@ui {"widget":"separator"}
//@input bool loadOnAwake = false