// RemoteAssetsLoader.js
// Version: 1.1.0
// Event: On Awake
// Description: Loads an array of RemoteAssetInfo.js script components and 
//              defines a global API for loading remote assets on demand

// ---- GLOBAL API USAGE ----
//
// global.RemoteAssetLoader.load(id, onActionComplete);

//@ui {"widget":"label", "label":"<b>Instructions:<b>"}
//@ui {"widget":"label", "label":"1. Place a Root scene object above RemoteAssetLoader.js "}
//@ui {"widget":"label", "label":"in the Objects panel hierarchy."}
//@ui {"widget":"label", "label":"2. Add RemoteAssetInfo.js to children of the Root."}
//@ui {"widget":"label", "label":"3. Configure RemoteAssetInfo.js inputs on Root children."}
//@ui {"widget":"label", "label":"4. Add the Root scene object to the Root input below."}
//@ui {"widget":"separator"}

//@input SceneObject remoteAssetsRoot {"label":"Root","hint":"Parent scene object of RemoteAssetInfo children"}

// Type Definition -----
/**
* @typedef {Object} RemoteAssetInfo
* @property {string} id
* @property {int} action
* @property {SceneObject} prefabParent
* @property {Component.AudioComponent} myAudioComponent
* @property {Component.Image} myImage
* @property {Asset.Material} myMaterial
* @property {string} texturePropertyName
* @property {Component.RenderMeshVisual} myRenderMeshVisual
* @property {Component.MLComponent} myMLComponent
* @property {Component.ScriptComponent} myScriptComponent
* @property {string} funcName
* @property {bool} loadOnAwake
*/

// Remote Assets Data Store -----
/** @type {{[id:string]:RemoteAssetInfo}} */
var remoteAssets = {};
var initialized = false;

// Helpers -----

function checkInputs() {
    if (!script.remoteAssetsRoot) {
        Studio.log("Error: Please input the Remote Assets Root");
        return false;
    } 
    if (script.remoteAssetsRoot.getChildrenCount() === 0) {
        Studio.log("Error: Please add children with a RemoteAssetInfo script component to the Root");
        return false;
    }
    for (var i = 0; i < script.remoteAssetsRoot.getChildrenCount(); i++) {
        var remoteAsset = script.remoteAssetsRoot.getChild(i).getComponent("Component.ScriptComponent");
        if (!remoteAsset) {
            Studio.log("Error: Please add Remote Asset Info script component to child " + i + " of Root");
            return false;            
        }
        if (!remoteAsset.id) {
            Studio.log("Error: Please add an ID to Root child " + i);
            return false;
        }
        if (!remoteAsset.referenceAsset) {
            Studio.log("Error: Please input a Reference Asset to remote asset with ID " + remoteAsset.id);
            return false;           
        }
    }
    return true;
}

function loadOnAwake() {
    for (var i = 0; i < script.remoteAssetsRoot.getChildrenCount(); i++) {
        var remoteAsset = script.remoteAssetsRoot.getChild(i).getComponent("Component.ScriptComponent");
        if (remoteAsset.loadOnAwake) {
            load(remoteAsset.id);    
        }
    } 
}

function onActionCompleteCallback(resource, remoteAsset, onActionComplete) {
    if (onActionComplete) {
        onActionComplete(resource);
    }
    if (remoteAsset.myScriptComponent && remoteAsset.funcName) {
        if (remoteAsset.myScriptComponent[remoteAsset.funcName]) {
            remoteAsset.myScriptComponent[remoteAsset.funcName](resource);
        } else if (remoteAsset.myScriptComponent.api[remoteAsset.funcName]) {
            remoteAsset.myScriptComponent.api[remoteAsset.funcName](resource);
        }
    }
}

function setAudio(asset, remoteAsset, onContentSet) {
    if (!asset.isOfType("Asset.AudioTrackAsset")) {
        Studio.log("Error: Asset type is not AudioTrack Asset and cannot be played in AudioComponent");
        return;
    }
    if (!remoteAsset.myAudioComponent) {
        Studio.log("Error: Audio Component is not set for remote asset " + remoteAsset.id);
        return;
    }
    remoteAsset.myAudioComponent.audioTrack = asset; 
    onActionCompleteCallback(remoteAsset.myAudioComponent, remoteAsset, onContentSet);
}

function setImageTexture(asset, remoteAsset, onContentSet) {
    if (!asset.isOfType("Asset.Texture")) {
        Studio.log("Error: Asset type is not Texture Asset and cannot be used in an Image");
        return;
    }    
    if (!remoteAsset.myImage) {
        Studio.log("Error: Image is not set for remote asset " + remoteAsset.id);
        return;
    }
    remoteAsset.myImage.mainMaterial.mainPass.baseTex = asset;
    onActionCompleteCallback(remoteAsset.myImage, remoteAsset, onContentSet);    
}

function setMaterialTexture(asset, remoteAsset, onContentSet) {
    if (!asset.isOfType("Asset.Texture")) {
        Studio.log("Error: Asset type is not Texture Asset and can not be used in  a Material");
        return; 
    }  
    if (!remoteAsset.myMaterial) {
        Studio.log("Error: Material is not set for remote asset " + remoteAsset.id);
        return;
    }
    if (!remoteAsset.texturePropertyName) {
        Studio.log("Error: Property is not set for remote asset " + remoteAsset.id);
        return;
    }
    remoteAsset.myMaterial.mainPass[remoteAsset.texturePropertyName] = asset;
    onActionCompleteCallback(remoteAsset.myImage, remoteAsset, onContentSet);   
}

function setMesh(asset, remoteAsset, onContentSet) {
    if (!asset.isOfType("Asset.RenderMesh")) {
        Studio.log("Error: Asset type is not Render Mesh and cannot be used in a Render Mesh Visual");
        return;
    } 
    if (!remoteAsset.myRenderMeshVisual) {
        Studio.log("Error: Render Mesh Visual is not set for remote asset " + remoteAsset.id);
        return;
    }
    remoteAsset.myRenderMeshVisual.mesh = asset;   
    onActionCompleteCallback(remoteAsset.myRenderMeshVisual, remoteAsset, onContentSet);
}

function setModel(asset, remoteAsset, onContentSet) {
    if (!asset.isOfType("Asset.MLAsset")) {
        Studio.log("Error: Asset type is not ML Asset and cannot be used in ML Component");
        return;
    }
     if (!remoteAsset.myMLComponent) {
        Studio.log("Error: ML Component is not set for remote asset " + remoteAsset.id);
        return;
    }
    if (!remoteAsset.myScriptComponent  && !onContentSet) {
        Studio.log("Tip: Configure your ML Component with an On Action Complete Callback");
    }
    remoteAsset.myMLComponent.model = asset;
    onActionCompleteCallback(remoteAsset.myMLComponent, remoteAsset, onContentSet);    
}

function setPrefab(asset, remoteAsset, onContentSet) {
    if (!asset.isOfType("Asset.ObjectPrefab")) {
        Studio.log("Error: Asset type is not Object Prefab and cannot be instantiated");
        return;
    }
    var instantiatedSo = asset.instantiate(remoteAsset.prefabParent || null);
    onActionCompleteCallback(instantiatedSo, remoteAsset, onContentSet);
}

// API -----

/**
 * Downloads a remote asset and performs its associated action to set Lens content
 * @param {string} id A unique identifier for the remote asset. For digital goods, this can be the item's SKU.
 * @param {()=>void} onActionComplete A callback function called after the remote asset is downloaded and Lens content is set
 */
function load(id, onActionComplete) {
    if (!initialized) {
        Studio.log("Error: Remote assets have not initialized, cannot load " + id);
        return;        
    }
    if (!id) {
        Studio.log("Error: ID is missing, cannot load remote asset");
        return;
    }
    if (!remoteAssets[id]) {
        Studio.log("Error: ID " + id + " not found in remote assets info");
        return;
    }
    var remoteAsset = remoteAssets[id];
    switch (remoteAsset.action) {
        case -1: // None
            remoteAsset.referenceAsset.downloadAsset(function(asset) {
                // On download success
                onActionCompleteCallback(asset, remoteAsset, onActionComplete);
            }, function() {
                // On download failure
                if (remoteAsset.fallbackAsset) {
                    onActionCompleteCallback(remoteAsset.fallbackAsset, remoteAsset, onActionComplete);
                }    
            });
            break;
        case 0: // Instantiate Prefab
            remoteAsset.referenceAsset.downloadAsset(function(asset) {
                // On download success
                setPrefab(asset, remoteAsset, onActionComplete); 
            }, function() {
                // On download failure
                if (remoteAsset.fallbackAsset) {
                    setPrefab(remoteAsset.fallbackAsset, remoteAsset, onActionComplete);
                }
            });
            break;
        case 1: // Set Audio Track
            remoteAsset.referenceAsset.downloadAsset(function(asset) {
                // On download success
                setAudio(asset, remoteAsset, onActionComplete); 
            }, function() {
                // On download failure
                if (remoteAsset.fallbackAsset) {
                    setAudio(remoteAsset.fallbackAsset, remoteAsset, onActionComplete);
                }
            });
            break;
        case 2: // Set Image Texture
            remoteAsset.referenceAsset.downloadAsset(function(asset) {
                // On download success
                setImageTexture(asset, remoteAsset, onActionComplete); 
            }, function() {
                // On download failure
                if (remoteAsset.fallbackAsset) {
                    setImageTexture(remoteAsset.fallbackAsset, remoteAsset, onActionComplete);
                }
            });
            break;
        case 3: // Set Material Texture
            remoteAsset.referenceAsset.downloadAsset(function(asset) {
                // On download success
                setMaterialTexture(asset, remoteAsset, onActionComplete); 
            }, function() {
                // On download failure
                if (remoteAsset.fallbackAsset) {
                    setMaterialTexture(remoteAsset.fallbackAsset, remoteAsset, onActionComplete);
                }
            });
            break;
        case 4: // Set Mesh
            remoteAsset.referenceAsset.downloadAsset(function(asset) {
                // On download success
                setMesh(asset, remoteAsset, onActionComplete); 
            }, function() {
                // On download failure
                if (remoteAsset.fallbackAsset) {
                    setMesh(remoteAsset.fallbackAsset, remoteAsset, onActionComplete);
                }
            });
            break;  
        case 5: // Set ML Asset
            remoteAsset.referenceAsset.downloadAsset(function(asset) {
                // On download success
                setModel(asset, remoteAsset, onActionComplete); 
            }, function() {
                // On download failure
                if (remoteAsset.fallbackAsset) {
                    setModel(remoteAsset.fallbackAsset, remoteAsset, onActionComplete);
                }
            });
            break; 
    } 
}

// Initialize and load remote assets on awake -----

function init() {
    if (!checkInputs()) {
        return;
    }
    for (var j = 0; j < script.remoteAssetsRoot.getChildrenCount(); j++) {
        var remoteAsset = script.remoteAssetsRoot.getChild(j).getComponent("Component.ScriptComponent");  
        if (!remoteAssets[remoteAsset.id]) {
            remoteAssets[remoteAsset.id] =  remoteAsset;        
        } else {
            Studio.log("Warning: Remote Asset with ID " + remoteAsset.id + " already exists, skipping setup.");
        }
    }
    initialized = true;
    loadOnAwake(); 
}

init();

// Global function in remoteAssets namespace -----

global.RemoteAssetLoader = {
    load : load
};