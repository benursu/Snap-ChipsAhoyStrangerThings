/* // NOTE: This file contains code for accessing an external API encapsulated as a JS module. You should not modify this file.
 * // Instead, you should modify the "Coke Tastebud Map Test Local API" script and access the functions through the imported class wrapper.
 */

// https://docs.snap.com/api/lens-studio/Classes/ScriptObjects/#RemoteApiResponse--statusCode
const statusMessageMap = {
    0: "Unknown Status Code - Please report this as a bug.",
    1: "Success",
    2: "Redirected",
    3: "Bad Request",
    4: "Access Denied",
    5: "API Call Not Found",
    6: "Timeout",
    7: "Request Too Large",
    8: "Server Processing Error",
    9: "Request Cancelled by Caller",
    10: "Internal Framework Error",
};

class RemoteApiService {
    constructor(remoteServiceModule) {
        this.remoteServiceModule = remoteServiceModule;
    }

    async performApiRequest(endpoint, request, paramsSchema) {
        request = request || {};

        for (const [name, optional] of paramsSchema || []) {
            const value = request.parameters && request.parameters[name];
            if (!optional && value == null) {
                throw new Error(`Required parameter ${name} is missing from request.`);
            }
        }

        const req = global.RemoteApiRequest.create();
        req.endpoint = endpoint;
        if (request.parameters) req.parameters = request.parameters;
        if (request.body) req.body = request.body;

        const response = await new Promise((resolve) => this.remoteServiceModule.performApiRequest(req, resolve));
        if (response.statusCode !== 1) {
            const message = statusMessageMap[response.statusCode] || statusMessageMap[0];
            throw new Error(`API Call Error - ${message}: ${response.body}.`);
        }

        return {
            statusCode: response.statusCode,
            metadata: response.metadata,
            bodyAsJson: () => JSON.parse(response.body),
            bodyAsString: () => response.body,
            bodyAsResource: () => response.asResource(),
        };
    }
}

/**
 * @typedef {Object} ApiCallResponse
 * @property {number} statusCode - The integer status code of the response. The meaning of possible status code values are defined as follows:
 * <ul>
 *   <li><strong>1:</strong> Success. This code corresponds to the 2XX HTTP response status codes.</li>
 *   <li><strong>2:</strong> Redirected. This code corresponds to the 3XX HTTP response status codes.</li>
 *   <li><strong>3:</strong> Bad request. This code corresponds to the 4XX HTTP response status codes other than 401, 403, 404, 408, 413, 414, and 431, which are mapped separately below.</li>
 *   <li><strong>4:</strong> Access denied. This code corresponds to the HTTP response status codes 401 and 403.</li>
 *   <li><strong>5:</strong> Not found. This code corresponds to the HTTP response status code 404. It is also returned when the API spec is not found by the remote API service.</li>
 *   <li><strong>6:</strong> Timeout. This code corresponds to the HTTP response status codes 408 and 504.</li>
 *   <li><strong>7:</strong> Request too large. This code corresponds to the HTTP response status codes 413, 414, and 431.</li>
 *   <li><strong>8:</strong> Server error. This code corresponds to the 5XX HTTP response status codes other than 504 (timeout).</li>
 *   <li><strong>9:</strong> Request cancelled by the caller.</li>
 *   <li><strong>10:</strong> Internal error happened inside the remote API framework (i.e., not from the remote service being called).</li>
 * </ul>
 * All other values have undefined meaning and should be treated as internal error (code 10).
 * @property {Object} metadata - The key-value pairs of the response metadata.
 * @property {function(): Object} bodyAsJson - Parses the response body as a JSON object.
 * @property {function(): string} bodyAsString - Reads the response body as a string.
 * @property {function(): DynamicResource} bodyAsResource - Converts the response body into a {@link https://docs.snap.com/api/lens-studio/Classes/ScriptObjects#DynamicResource|DynamicResource} object, which can be used by the {@link https://docs.snap.com/api/lens-studio/Classes/Assets#RemoteMediaModule|RemoteMediaModule} to load the media content.
 */

/**
 * ApiModule Remote API service.
 */
class ApiModule extends RemoteApiService {
    /**
     * Performs user_login API call.
     *
     * @param {Object} request - The request object for the API call.
     * @param {Object} request.parameters - Parameters for the API call.
     * @param {string=} request.body - Body content for the API request, if applicable. Typically a JSON string.
     * @returns {Promise<ApiCallResponse>} - A promise that resolves to the API response.
     *
     * @example
     * user_login({
     *   body: JSON.stringify({
     *     "additionalInfo": "Some info"
     *   })
     * }).then(response => {
     *     print(response.bodyAsJson());
     * }).catch(error => {
     *     print(error);
     * });
     */
    user_login(request) {
        return this.performApiRequest("user_login", request);
    }

    /**
     * Performs user_authenticated API call.
     *
     * @param {Object} request - The request object for the API call.
     * @param {Object} request.parameters - Parameters for the API call.
     * @param {string=} request.body - Body content for the API request, if applicable. Typically a JSON string.
     * @returns {Promise<ApiCallResponse>} - A promise that resolves to the API response.
     *
     * @example
     * user_authenticated({
     *   body: JSON.stringify({
     *     "additionalInfo": "Some info"
     *   })
     * }).then(response => {
     *     print(response.bodyAsJson());
     * }).catch(error => {
     *     print(error);
     * });
     */
    user_authenticated(request) {
        return this.performApiRequest("user_authenticated", request);
    }

    /**
     * Performs capture_photo API call.
     *
     * @param {Object} request - The request object for the API call.
     * @param {Object} request.parameters - Parameters for the API call.
     * @param {string=} request.body - Body content for the API request, if applicable. Typically a JSON string.
     * @returns {Promise<ApiCallResponse>} - A promise that resolves to the API response.
     *
     * @example
     * capture_photo({
     *   body: JSON.stringify({
     *     "additionalInfo": "Some info"
     *   })
     * }).then(response => {
     *     print(response.bodyAsJson());
     * }).catch(error => {
     *     print(error);
     * });
     */
    capture_photo(request) {
        return this.performApiRequest("capture_photo", request);
    }

    /**
     * Performs profile_set API call.
     *
     * @param {Object} request - The request object for the API call.
     * @param {Object} request.parameters - Parameters for the API call.
     * @param {string} request.parameters.flavor0 - flavor0 parameter value.
     * @param {string} request.parameters.flavor1 - flavor1 parameter value.
     * @param {string} request.parameters.flavor2 - flavor2 parameter value.
     * @param {string} request.parameters.flavor0_percentage - flavor0_percentage parameter value.
     * @param {string} request.parameters.flavor1_percentage - flavor1_percentage parameter value.
     * @param {string} request.parameters.flavor2_percentage - flavor2_percentage parameter value.
     * @param {string} request.parameters.product - product parameter value.
     * @param {string} request.parameters.food - food parameter value.
     * @param {string=} request.body - Body content for the API request, if applicable. Typically a JSON string.
     * @returns {Promise<ApiCallResponse>} - A promise that resolves to the API response.
     *
     * @example
     * profile_set({
     *   parameters: {
     *     "flavor0": "value1",
     *     "flavor1": "value2",
     *     "flavor2": "value3",
     *     "flavor0_percentage": "value4",
     *     "flavor1_percentage": "value5",
     *     "flavor2_percentage": "value6",
     *     "product": "value7",
     *     "food": "value8",
     *   },
     *   body: JSON.stringify({
     *     "additionalInfo": "Some info"
     *   })
     * }).then(response => {
     *     print(response.bodyAsJson());
     * }).catch(error => {
     *     print(error);
     * });
     */
    profile_set(request) {
        return this.performApiRequest("profile_set", request, [
            ["flavor0", true],
            ["flavor1", true],
            ["flavor2", true],
            ["flavor0_percentage", true],
            ["flavor1_percentage", true],
            ["flavor2_percentage", true],
            ["product", true],
            ["food", true],
        ]);
    }

    /**
     * Performs profile_clear API call.
     *
     * @param {Object} request - The request object for the API call.
     * @param {Object} request.parameters - Parameters for the API call.
     * @param {string=} request.body - Body content for the API request, if applicable. Typically a JSON string.
     * @returns {Promise<ApiCallResponse>} - A promise that resolves to the API response.
     *
     * @example
     * profile_clear({
     *   body: JSON.stringify({
     *     "additionalInfo": "Some info"
     *   })
     * }).then(response => {
     *     print(response.bodyAsJson());
     * }).catch(error => {
     *     print(error);
     * });
     */
    profile_clear(request) {
        return this.performApiRequest("profile_clear", request);
    }

    /**
     * Performs analytics API call.
     *
     * @param {Object} request - The request object for the API call.
     * @param {Object} request.parameters - Parameters for the API call.
     * @param {string} request.parameters.event - event parameter value.
     * @param {string=} request.body - Body content for the API request, if applicable. Typically a JSON string.
     * @returns {Promise<ApiCallResponse>} - A promise that resolves to the API response.
     *
     * @example
     * analytics({
     *   parameters: {
     *     "event": "value1",
     *   },
     *   body: JSON.stringify({
     *     "additionalInfo": "Some info"
     *   })
     * }).then(response => {
     *     print(response.bodyAsJson());
     * }).catch(error => {
     *     print(error);
     * });
     */
    analytics(request) {
        return this.performApiRequest("analytics", request, [
            ["event", false],
        ]);
    }
    
    /**
     * Performs profile_get API call.
     *
     * @param {Object} request - The request object for the API call.
     * @param {Object} request.parameters - Parameters for the API call.
     * @param {string=} request.body - Body content for the API request, if applicable. Typically a JSON string.
     * @returns {Promise<ApiCallResponse>} - A promise that resolves to the API response.
     *
     * @example
     * profile_get({
     *   body: JSON.stringify({
     *     "additionalInfo": "Some info"
     *   })
     * }).then(response => {
     *     print(response.bodyAsJson());
     * }).catch(error => {
     *     print(error);
     * });
     */
    profile_get(request) {
        return this.performApiRequest("profile_get", request);
    }


    /**
     * Performs get_image API call.
     *
     * @param {Object} request - The request object for the API call.
     * @param {Object} request.parameters - Parameters for the API call.
     * @param {string} request.parameters.imageId - event parameter value.
     * @param {string=} request.body - Body content for the API request, if applicable. Typically a JSON string.
     * @returns {Promise<ApiCallResponse>} - A promise that resolves to the API response.
     *
     * @example
     * get_image({
     *   parameters: {
     *     "imageId": "value1",
     *   },
     *   body: JSON.stringify({
     *     "additionalInfo": "Some info"
     *   })
     * }).then(response => {
     *     print(response.bodyAsJson());
     * }).catch(error => {
     *     print(error);
     * });
     */
    get_image(request) {
        return this.performApiRequest("get_image", request, [
            ["imageId", false],
        ]);
    }


    /**
     * Performs loadResource API call.
     *
     * @param {Object} request - The request object for the API call.
     * @param {Object} request.parameters - Parameters for the API call.
     * @param {string} request.parameters.url - event parameter value.
     * @param {string=} request.body - Body content for the API request, if applicable. Typically a JSON string.
     * @returns {Promise<ApiCallResponse>} - A promise that resolves to the API response.
     *
     * @example
     * loadResource({
     *   parameters: {
     *     "url": "value1",
     *   },
     *   body: JSON.stringify({
     *     "additionalInfo": "Some info"
     *   })
     * }).then(response => {
     *     print(response.bodyAsJson());
     * }).catch(error => {
     *     print(error);
     * });
     */
    loadResource(request) {
        return this.performApiRequest("loadResource", request, [
            ["url", false],
        ]);
    }
    
}

module.exports.ApiModule = ApiModule;
