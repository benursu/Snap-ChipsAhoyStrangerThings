// @input bool debug
// @input Component.Text debugTextText

// @input Asset.RemoteServiceModule remoteServiceModule
// @input Asset.RemoteMediaModule remoteMediaModule

// @input Component.Image loadResourceImageImage
// @input Component.Image loadResourceVideoImage
// @input SceneObject loadResourceModel
// @input Asset.Material loadResourceModelMaterial


const Module = require("./Chips Ahoy Stranger Things API Module");
const ApiModule = new Module.ApiModule(script.remoteServiceModule);



/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//vars

var mode = 'preload'; //preload,preloadStarted,preloadComplete,intro,scan,scanComplete,flavorProfileCharge,authenticate,authenticateComplete,pairing,pairingCharge,pairingComplete

global.debug = script.debug;
global.debugApiDelay = 1;



/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//analytics

function analytics(event){
  if(!global.debug){
    ApiModule.analytics({
      parameters: {
        "event": event
      },

    }).then((response) => {
      var metadata = response.metadata;
      var data = response.bodyAsJson();

    }).catch((error) => {
      script.debugTextText.text += 'analytics:' + error + "\n" + error.stack;

    });

  }

}

// analytics('Lens Start');



/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//load resource

//
function loadResourceImage(url){
  ApiModule.loadResource({
    parameters: {
      'url': url
    },
  
  }).then((response) => {
    var metadata = response.metadata;
    // var data = response.bodyAsJson();

    script.remoteMediaModule.loadResourceAsImageTexture(
      response.bodyAsResource(),
      function (texture) {
        script.loadResourceImageImage.mainMaterial.mainPass.baseTex = texture;
  
      },
      function (error) {
        // handle error
        script.debugTextText.text += '...loadResourceAsImage:' + error;
      }
    );
  
  }).catch((error) => {
    script.debugTextText.text += '...loadResourceAsImage:' + error + "\n" + error.stack;
  
  });
  
}

loadResourceImage('/unmute-btn.png');


//
function loadResourceVideo(url){
  ApiModule.loadResource({
    parameters: {
      'url': url
    },
  
  }).then((response) => {
    var metadata = response.metadata;
    // var data = response.bodyAsJson();

    script.remoteMediaModule.loadResourceAsVideoTexture(
      response.bodyAsResource(),
      function (texture) {
        // texture.control.play(-1, 0);
        script.loadResourceVideoImage.mainMaterial.mainPass.baseTex = texture;
  
        //
        var introUpdateEvent = script.createEvent("UpdateEvent");
        introUpdateEvent.bind(function(eventData)
        {
          if(script.loadResourceVideoImage.mainMaterial.mainPass.baseTex.control.getLoadStatus() == LoadStatus.Loaded && script.loadResourceVideoImage.mainMaterial.mainPass.baseTex.control.getStatus() == VideoStatus.Stopped){
            script.loadResourceVideoImage.mainMaterial.mainPass.baseTex.control.play(-1); 
          }
        });        
        
      },
      function (error) {
        // handle error
        script.debugTextText.text += '...loadResourceVideo:' + error;
      }
    );
  
  }).catch((error) => {
    script.debugTextText.text += '...loadResourceVideo:' + error + "\n" + error.stack;
  
  });
  
}

loadResourceVideo('/train.mp4');

//
function loadResourceGLTF(url){
  ApiModule.loadResource({
    parameters: {
      'url': url
    },
  
  }).then((response) => {
    var metadata = response.metadata;
    // var data = response.bodyAsJson();

    script.remoteMediaModule.loadResourceAsGltfAsset(
      response.bodyAsResource(),
      function (gltfAsset) {
  
        let settings = GltfSettings.create();
        // settings.convertMetersToCentimeters = true;
        let model = gltfAsset.tryInstantiateWithSetting(
          script.loadResourceModel,
          script.loadResourceModelMaterial,
          settings
        );

  
      },
      function (error) {
        // handle error
        script.debugTextText.text += '...loadResourceGLTF:' + error;
      }
    );
  
  }).catch((error) => {
    script.debugTextText.text += '...loadResourceGLTF:' + error + "\n" + error.stack;
  
  });
  
}

loadResourceGLTF('/shiba.glb');
