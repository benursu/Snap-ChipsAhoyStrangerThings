// @input bool debug
// @input Component.Text debugTextText

// @input Asset.RemoteServiceModule remoteServiceModule
const Module = require("./Chips Ahoy Stranger Things API Module");
const ApiModule = new Module.ApiModule(script.remoteServiceModule);
