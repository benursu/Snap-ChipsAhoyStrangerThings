// @input bool debug
// @input Component.Text debugTextText

// @input Asset.RemoteServiceModule remoteServiceModule
// @input Asset.RemoteMediaModule remoteMediaModule
// @input Component.Image targetImage

const Module = require("./Chips Ahoy Stranger Things API Module");
const ApiModule = new Module.ApiModule(script.remoteServiceModule);



/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//vars

var mode = 'preload'; //preload,preloadStarted,preloadComplete,intro,scan,scanComplete,flavorProfileCharge,authenticate,authenticateComplete,pairing,pairingCharge,pairingComplete

global.debug = script.debug;
global.debugApiDelay = 1;





/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//analytics

function analytics(event){
  if(!global.debug){
    ApiModule.analytics({
      parameters: {
        "event": event
      },

    }).then((response) => {
      var metadata = response.metadata;
      var data = response.bodyAsJson();

    }).catch((error) => {
      script.debugTextText.text += 'analytics:' + error + "\n" + error.stack;

    });

  }

}

analytics('Lens Start');



/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//load resource

function loadResource(imageId){
  ApiModule.get_image({
    parameters: {
      'imageId': imageId
    },
  
  }).then((response) => {
    // var metadata = response.metadata;
    // var data = response.bodyAsJson();
  
    remoteMediaModule.loadResourceAsImageTexture(
      response.asResource(),
      function (texture) {
        // if the response was successfully converted to an imageTexture,
        // pass the texture to the callback function
        // cb(texture);
  
        script.targetImage.mainMaterial.mainPass.baseTex = texture;
  
      },
      function (error) {
        // handle error
      }
    );
  
  }).catch((error) => {
    script.debugTextText.text += 'loadResource:' + error + "\n" + error.stack;
  
  });
  
}

loadResource('test');