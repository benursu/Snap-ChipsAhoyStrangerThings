// @input bool debug
// @input Component.Text debugTextText

// @input Asset.RemoteServiceModule remoteServiceModule
const Module = require("./Chips Ahoy Stranger Things API Module");
const ApiModule = new Module.ApiModule(script.remoteServiceModule);



/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//vars

var mode = 'preload'; //preload,preloadStarted,preloadComplete,intro,scan,scanComplete,flavorProfileCharge,authenticate,authenticateComplete,pairing,pairingCharge,pairingComplete

global.debug = script.debug;
global.debugApiDelay = 1;





/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//analytics

function analytics(event){
    script.debugTextText.text += '1';
    if(!global.debug){
        script.debugTextText.text += 'a';
      ApiModule.analytics({
        parameters: {
          "event": event
        },
      }).then((response) => {
        script.debugTextText.text += '2';
          var metadata = response.metadata;
          var data = response.bodyAsJson();
  
      }).catch((error) => {
        script.debugTextText.text += '3';
          script.debugTextText.text += 'analytics:' + error + "\n" + error.stack;
  
      });
  
    }
  
  }
  
  analytics('Lens Start');