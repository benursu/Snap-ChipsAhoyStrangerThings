"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RotationPoint = void 0;
const SidePoint_1 = require("./SidePoint");
class RotationPoint extends SidePoint_1.SidePoint {
    constructor(sceneObject) {
        super(sceneObject);
    }
}
exports.RotationPoint = RotationPoint;
//# sourceMappingURL=RotationPoint.js.map